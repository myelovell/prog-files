require_relative "lib/concatenate.rb"

x = concatenate("hello", "world")
puts x
