# Concatenate

## Beskrivning

Skriv en funktion som tar två strängar som input och returnerar en ny sträng som är de två strängarna konkatenerade.