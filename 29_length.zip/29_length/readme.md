# Length

## Beskrivning

Skriv en funktion som tar en sträng som input och returnerar strängens längd - utan att använda `#length`, `#size` eller `#count` eller liknande.