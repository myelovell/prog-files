require_relative "lib/length.rb"

x = length("hello")

puts x
