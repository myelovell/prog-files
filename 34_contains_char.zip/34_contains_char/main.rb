require_relative "lib/contains_char.rb"

x = contains_char("hello", "h")
puts x

y = contains_char("hello", "k")
puts y
