require_relative "lib/chomp.rb"

x = chomp("hello\n")
puts x

y = chomp("hello")
puts y
