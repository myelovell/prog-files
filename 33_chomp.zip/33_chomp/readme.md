# Chomp

## Beskrivning


Skriv en funktion som tar en sträng som input. Om strängen slutar med en radbrytning ska funktionen returnera en ny sträng bestående av den ingående strängen, men utan radbrytningen. Om strängen inte slutar med en radbrytning returneras den ingående strängen oförändrad.
