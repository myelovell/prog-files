#2019-12-04, radbrytning? delete that bitch!

def chomp(str)
    if str[str.length - 1] == "\n"
        str[str.length - 1] = ""
        return str
    else
        puts "lol your code didn't have radbrytning lmao noob"
        return str
    end
end
