# Ends With

## Beskrivning


Skriv en funktion som tar en sträng och ett tecken (en sträng med enbart ett tecken i) som input och returnerar true om den sista strängens sista tecken är tecknet i den andra strängen. Annars skall funktionen returnera false.
